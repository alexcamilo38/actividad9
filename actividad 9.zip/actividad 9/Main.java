
package paquete1;


public class Main {
     public static void main(String[] args) {
         Circulo obj1=new Circulo();
         Rectangulo obj2=new Rectangulo();
         Trianguloisosceles obj3=new Trianguloisosceles();
         Trianguloequilatero obj4= new Trianguloequilatero();
         Trianguloobtuso obj5 = new Trianguloobtuso();
         
         
         obj1.setNombre("circulo");
         obj1.setRadio(10);
         obj1.CalcularArea(20);
         
         
         obj2.setBase(2);
         obj2.setAltura(5);
         obj2.calcularArea();
         
         
         
         obj3.setAltura(0);
     }
}
