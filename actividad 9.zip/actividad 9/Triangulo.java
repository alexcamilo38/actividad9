
package paquete1;


public class Triangulo  extends Figurageometrica {
     @Override
    public void mostrarInfo() {
        
    }

    @Override
    public double calcularArea() {
        
        return 0;
        
    }

    @Override
    public double calcularPerimetro() {
        
        return 0;
        
    }
    
    
    
}
