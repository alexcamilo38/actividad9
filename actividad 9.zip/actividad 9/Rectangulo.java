//
package paquete1;


public class Rectangulo extends Figurageometrica {
    private double base;
    private double altura;
    
      public void setBase(double base) {
        this.base = base;
    }

    public double getBase() {
        return base;
    }

     public void setAltura(double altura) {
        this.altura = altura;
    }
    public double getAltura() {
        return altura;
    }
  
    public double calcularArea(){
        return base * altura;
        
    }

    @Override
    public void mostrarInfo() {
        
    }

    @Override
    public double calcularPerimetro() {
     
        return 0;
     
    }
    
    
}
