
package paquete1;

public class Trianguloequilatero  extends Triangulo{
    
    private double lado;
    private String nombre;
    public void setLado(double lado) {
        this.lado = lado;
    }
    public double getLado() {
        return lado;
    }

    
 
     public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getNombre() {
        return nombre;
    }

   }
  
   
        
    
    

