
package paquete1;


public class Circulo extends Figurageometrica{
    private double pi=3.1415;
    private double radio;
    private String nombre;
    private double calculararea;
    
    public void CalcularArea(double calculararea) {
        this.calculararea = calculararea;
    }
    
     public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getNombre() {
        return nombre;
    }

    public void setPi(double pi) {
        this.pi = pi;
    }
    public double getPi() {
        return pi;
    }

       public void setRadio(double radio) {
        this.radio = radio;
    }

    public double getRadio() {
        return radio;
    } 

    @Override
    public void mostrarInfo() {
    }

    @Override
    public double calcularArea() {
        return 0;
    }

    @Override
    public double calcularPerimetro() {
        return 0;
    }
    
}
