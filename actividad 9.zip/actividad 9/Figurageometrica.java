//declaromos la super clase FiguraGeometrica, teniendo en cuenta que se trata una clase abstracta
package paquete1;


public abstract class Figurageometrica {
    public String nombre;
    public abstract void mostrarInfo();
    public abstract double calcularArea();
    public abstract double calcularPerimetro();
    
}
