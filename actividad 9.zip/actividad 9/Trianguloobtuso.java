
package paquete1;


public class Trianguloobtuso extends Triangulo{
  private double anguloMayor; // En grados

    public Trianguloobtuso(double base, double altura, double lado1, double lado2, double lado3, double anguloMayor) {
        
        this.anguloMayor = anguloMayor;
        super.nombre = "Triángulo Obtuso";
    }

    Trianguloobtuso() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public double getAnguloMayor() {
        return anguloMayor;
    }

    public void setAnguloMayor(double anguloMayor) {
        this.anguloMayor = anguloMayor;
    }

    public boolean esObtuso() {
        return anguloMayor > 90 && anguloMayor < 180;
    }
    
}
